package Data;

public enum moveType_t {Attack, Boost, Lower, Heal}
