package Data.Moves.Lower;
import Data.trait_t;

import Data.Lower;

public class Flash extends Lower {
    public Flash() {
        super("Flash", 5, trait_t.accuracy);
    }
}
