package Data.Moves.Lower;
import Data.trait_t;

//Lowers opponent's Attack

import Data.Lower;

public class Growl extends Lower{
    public Growl() {
        super("Growl", 10, trait_t.attack);
    }
}
