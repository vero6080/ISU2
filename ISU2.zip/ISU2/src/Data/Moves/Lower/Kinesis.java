package Data.Moves.Lower;
import Data.trait_t;

//Lowers opponent's Accuracy

import Data.Lower;

public class Kinesis extends Lower{
    public Kinesis() {
        super("Kinesis", 13, trait_t.accuracy);
    }
}