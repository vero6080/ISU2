package Data.Moves.Lower;
import Data.trait_t;

//Sharply lowers opponent's Speed

import Data.Lower;

public class StringShot extends Lower{
    public StringShot() {
        super("StringShot", 30, trait_t.speed);
    }
}
