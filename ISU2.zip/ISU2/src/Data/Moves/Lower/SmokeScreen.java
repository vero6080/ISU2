package Data.Moves.Lower;
import Data.trait_t;

import Data.Lower;

public class SmokeScreen extends Lower {
    public SmokeScreen() {
        super("SmokeScreen", 10, trait_t.accuracy);
    }
}
