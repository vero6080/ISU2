package Data.Moves.Lower;
import Data.trait_t;

import Data.Lower;

public class Leer extends Lower {
    public Leer() {
        super("Leer", 10, trait_t.defense);
    }
}
