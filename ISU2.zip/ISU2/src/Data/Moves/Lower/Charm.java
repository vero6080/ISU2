package Data.Moves.Lower;
import Data.trait_t;

import Data.Lower;

public class Charm extends Lower {
    public Charm() {
        super("Charm", 15, trait_t.attack);
    }
}
