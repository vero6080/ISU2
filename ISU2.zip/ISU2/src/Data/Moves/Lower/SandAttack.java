package Data.Moves.Lower;
import Data.trait_t;

//Lowers opponent's Accuracy

import Data.Lower;

public class SandAttack extends Lower{
    public SandAttack() {
        super("SandAttack", 15, trait_t.accuracy);
    }
}