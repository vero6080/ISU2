package Data.Moves.Lower;
import Data.trait_t;

//Lowers opponent's Defense

import Data.Lower;

public class TailWhip extends Lower{
    public TailWhip() {
        super("TailWhip", 20, trait_t.defense);
    }
}
