package Data.Moves.Lower;
import Data.trait_t;

import Data.Lower;

public class Screech extends Lower {
    public Screech() {
        super("Screech", 12, trait_t.defense);
    }
}
