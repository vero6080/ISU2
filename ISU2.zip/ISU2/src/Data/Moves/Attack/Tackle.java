package Data.Moves.Attack;

import Data.status_t;
import Data.Attack;

public class Tackle extends Attack {
    public Tackle() {
        super("Tackle", 15, status_t.none);
    }
}
