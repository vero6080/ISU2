package Data.Moves.Attack;
import Data.Attack;
import Data.status_t;

public class HornAttack extends Attack{
    public HornAttack() {
        super("HornAttack", 25, status_t.none);
    }
}