package Data.Moves.Attack;

import Data.status_t;
import Data.Attack;

public class QuickAttack extends Attack {
    public QuickAttack() {
        super("QuickAttack", 10, status_t.none);
    }
}
