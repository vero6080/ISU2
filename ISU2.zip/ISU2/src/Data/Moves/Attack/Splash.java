package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

//Does nothing
public class Splash extends Attack{
    public Splash() {
        super("Splash", 0, status_t.none);
    }
}
