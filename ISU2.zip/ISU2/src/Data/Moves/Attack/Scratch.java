package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

public class Scratch extends Attack{
    public Scratch() {
        super("Scratch", 25, status_t.none);
    }
}
