package Data.Moves.Attack;
import Data.Attack;
import Data.status_t;

public class WaterGun extends Attack{
    public WaterGun() {
        super("WaterGun", 30, status_t.none);
    }
}