package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

public class Pound extends Attack{
    public Pound() {
        super("Pound", 27, status_t.none);
    }
}
