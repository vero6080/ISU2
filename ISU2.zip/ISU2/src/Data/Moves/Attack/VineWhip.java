package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

public class VineWhip extends Attack{
    public VineWhip() {
        super("VineWhip", 20, status_t.none);
    }
}
