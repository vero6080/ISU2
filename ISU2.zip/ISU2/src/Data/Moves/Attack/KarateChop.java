package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

public class KarateChop extends Attack{
    public KarateChop() {
        super("KarateChop", 18, status_t.none);
    }
}
