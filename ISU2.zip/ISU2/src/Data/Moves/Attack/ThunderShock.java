package Data.Moves.Attack;

import Data.status_t;
import Data.Attack;

public class ThunderShock extends Attack {
    public ThunderShock() {
        super("ThunderShock", 30, status_t.none);
    }
}
