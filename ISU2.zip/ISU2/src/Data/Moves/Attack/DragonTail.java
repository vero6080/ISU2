package Data.Moves.Attack;

import Data.Attack;
import Data.status_t;

public class DragonTail extends Attack{
    public DragonTail() {
        super("DragonTail", 30, status_t.none);
    }
}
