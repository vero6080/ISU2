package Data.Moves.Boost;

import Data.Boost;
import Data.trait_t;

public class Growth extends Boost{
    public Growth() {
        super("Growth", 16, trait_t.attack);
    }
}
