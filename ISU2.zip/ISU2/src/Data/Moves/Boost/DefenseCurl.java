package Data.Moves.Boost;
import Data.trait_t;

//Raises user's Defense

import Data.Boost;

public class DefenseCurl extends Boost{
    public DefenseCurl() {
        super("DefenseCurl", 20, trait_t.defense);
    }
}
