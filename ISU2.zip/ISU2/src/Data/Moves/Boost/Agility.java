package Data.Moves.Boost;
import Data.trait_t;

//Sharply raises user's Speed

import Data.Boost;

public class Agility extends Boost{
    public Agility(){
        super("Agility", 18, trait_t.speed);
    }
}
