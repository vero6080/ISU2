package Data.Moves.Boost;
import Data.trait_t;

//Raises user's Defense

import Data.Boost;

public class Withdraw extends Boost{
    public Withdraw() {
        super("Withdraw", 20, trait_t.defense);
    }
}
