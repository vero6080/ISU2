package Data.Moves.Boost;
import Data.trait_t;

//Sharply raises user's Attack

import Data.Boost;

public class SwordsDance extends Boost{
    public SwordsDance() {
        super("SwordsDance", 30, trait_t.attack);
    }
}
