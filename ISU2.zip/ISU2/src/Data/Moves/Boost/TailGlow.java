package Data.Moves.Boost;
import Data.trait_t;

import Data.Boost;

public class TailGlow extends Boost {
    public TailGlow() {
        super("TailGlow", 25, trait_t.attack);
    }
}
