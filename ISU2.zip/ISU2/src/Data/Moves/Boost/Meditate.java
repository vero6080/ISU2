package Data.Moves.Boost;
import Data.trait_t;

//Raises user's Attack

import Data.Boost;

public class Meditate extends Boost {
    public Meditate() {
        super("Meditate", 15, trait_t.attack);
    }
}