package Data;

public enum trait_t {attack, defense, speed, accuracy}
