package Data;

public enum type_t {water, fire, grass, electric, normal}
