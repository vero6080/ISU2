package Data;

public enum status_t {none, poison, burn, freeze, sleep, paralyze}
